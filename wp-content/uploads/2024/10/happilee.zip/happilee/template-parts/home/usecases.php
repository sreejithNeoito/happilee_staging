<div class="container py-10 px-8">
    <div class="flex gap-6 mdd smd:flex-col">
        <div class="flex flex-1 gap-4 flex-col">
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/usecases/one.png" alt="" class="relative bg-transparent z-10 w-full">
            <h2 class="text-20 leading-5 text-primary font-semibold">Enhance Customer Support with <span class=" text-secondary">Whatsapp</span> Chatbot</h2>
            <p class="text-16 leading-6 text-black">Respond to customers instantly and effortlessly, allowing you to focus on your business to the next level.</p>
            <a href="#" class="bg-transparent border block w-max border-primary  text-primary text-16 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                Learn More
            </a>
        </div>
        <div class="flex flex-1 gap-4 flex-col">
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/usecases/one.png" alt="" class="relative bg-transparent z-10 w-full">
            <h2 class="text-20 leading-5 text-primary font-semibold">Enhance Customer Support with <span class=" text-secondary">Whatsapp</span> Chatbot</h2>
            <p class="text-16 leading-6 text-black">Respond to customers instantly and effortlessly, allowing you to focus on your business to the next level.</p>
            <a href="#" class="bg-transparent border block w-max border-primary  text-primary text-16 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                Learn More
            </a>
        </div>
        <div class="flex flex-1 gap-4 flex-col">
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/usecases/one.png" alt="" class="relative bg-transparent z-10 w-full">
            <h2 class="text-20 leading-5 text-primary font-semibold">Enhance Customer Support with <span class=" text-secondary">Whatsapp</span> Chatbot</h2>
            <p class="text-16 leading-6 text-black">Respond to customers instantly and effortlessly, allowing you to focus on your business to the next level.</p>
            <a href="#" class="bg-transparent border block w-max border-primary  text-primary text-16 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                Learn More
            </a>
        </div>
    </div>
</div>