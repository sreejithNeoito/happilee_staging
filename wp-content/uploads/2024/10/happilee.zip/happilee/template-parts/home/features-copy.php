<div class="container py-10 my-10 ">
    <h2 class="text-center text-24 leading-[26px] text-primary mb-6 mdd:px-5">Key Features of <br><span class="font-bold">Happilee Automation</span></h2>
    <div class="flex gap-4 items-center features-happilee">
        <a href="#feat-one" class="flex flex-col items-center justify-center rounded-xl p-4 gap-2 bg-white hover:bg-bg-footer cursor-pointer scroll-to">
            <svg width="29" height="28" viewBox="0 0 29 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M27.5 14.0807V20.5404M14.5 1.80745V7.62112M1.5 14.0807V20.5404M21 27H8C6.2125 27 4.75 25.5466 4.75 23.7702V10.8509C4.75 9.07454 6.2125 7.62112 8 7.62112H21C22.7875 7.62112 24.25 9.07454 24.25 10.8509V23.7702C24.25 25.5466 22.7875 27 21 27ZM11.25 14.8882C11.25 15.3341 10.8862 15.6957 10.4375 15.6957C9.98877 15.6957 9.625 15.3341 9.625 14.8882C9.625 14.4423 9.98877 14.0807 10.4375 14.0807C10.8862 14.0807 11.25 14.4423 11.25 14.8882ZM19.2125 14.8882C19.2125 15.3341 18.8487 15.6957 18.4 15.6957C17.9513 15.6957 17.5875 15.3341 17.5875 14.8882C17.5875 14.4423 17.9513 14.0807 18.4 14.0807C18.8487 14.0807 19.2125 14.4423 19.2125 14.8882ZM15.8 2.29193C15.8 3.00544 15.218 3.58385 14.5 3.58385C13.782 3.58385 13.2 3.00544 13.2 2.29193C13.2 1.57841 13.782 1 14.5 1C15.218 1 15.8 1.57841 15.8 2.29193Z" stroke="#0B3966" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" />
            </svg>
            <div class="text-16 font-medium font-second leadin-[20] whitespace-nowrap">Chatbot Builder</div>
        </a>
        <a href="#feat-two" class="flex flex-col items-center justify-center rounded-xl p-4 gap-2 bg-white hover:bg-bg-footer cursor-pointer scroll-to">
            <svg width="25" height="26" viewBox="0 0 25 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8.18752 15.1563H13.9375M8.18752 10.8438H16.8125M10.1947 1.72199C5.60745 2.57847 2.02369 6.28989 1.16358 10.8578C0.733531 13.57 1.16358 16.2822 2.31039 18.4234L1.02023 23.9905C1.02023 24.276 1.16358 24.4187 1.45028 24.4187L7.04095 23.134C9.19121 24.276 11.9149 24.847 14.6385 24.276C19.2257 23.4195 22.9529 19.8508 23.813 15.2829C25.2465 7.14637 18.2223 0.151777 10.1947 1.72199Z" stroke="#0B3966" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" />
            </svg>

            <div class="text-16 font-medium font-second leadin-[20] whitespace-nowrap">Team Inbox</div>
        </a>
        <a class="flex flex-col items-center justify-center rounded-xl p-4 gap-2 bg-white hover:bg-bg-footer cursor-pointer">
            <svg width="27" height="26" viewBox="0 0 27 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8.36097 8.2L12.9 25M25.4218 17.39L21.466 2.65509C21.0359 1.05304 19.0669 0.46282 17.8236 1.56322L15.3304 3.76982C12.5558 6.22536 9.24668 8.00245 5.66482 8.96035C2.66659 9.76218 0.889703 12.847 1.69307 15.8394C2.49644 18.8319 5.58064 20.6167 8.57887 19.8148C12.1607 18.8569 15.9168 18.7444 19.5498 19.4865L22.8144 20.1532C24.4424 20.4857 25.8518 18.992 25.4218 17.39Z" stroke="#0B3966" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>

            <div class="text-16 font-medium font-second leadin-[20] whitespace-nowrap">Broadcaster</div>
        </a>
        <a class="flex flex-col items-center justify-center rounded-xl p-4 gap-2 bg-white hover:bg-bg-footer cursor-pointer">
            <svg width="27" height="26" viewBox="0 0 27 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18.3 7V3.4C18.3 2.07452 17.2255 1 15.9 1H11.1C9.77452 1 8.7 2.07452 8.7 3.4V7M25.5 13L13.9706 15.3059C13.66 15.368 13.34 15.368 13.0294 15.3059L1.5 13M1.5 9.4C1.5 8.07452 2.57452 7 3.9 7H23.1C24.4255 7 25.5 8.07452 25.5 9.4V22.6C25.5 23.9255 24.4255 25 23.1 25H3.9C2.57452 25 1.5 23.9255 1.5 22.6V9.4Z" stroke="#0B3966" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>


            <div class="text-16 font-medium font-second leadin-[20] whitespace-nowrap">WhatsApp Commerce</div>
        </a>
        <a class="flex flex-col items-center justify-center rounded-xl p-4 gap-2 bg-white hover:bg-bg-footer cursor-pointer">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.5 3.2H3.2C1.98497 3.2 1 4.18497 1 5.4V8.7M6.5 3.2H15.3M6.5 3.2V1M6.5 3.2V5.4M1 8.7H20.8V5.4C20.8 4.18497 19.8151 3.2 18.6 3.2H15.3M1 8.7V20.8C1 22.0151 1.98497 23 3.2 23H8.7M15.3 3.2V1M15.3 3.2V5.4M17.5 15.575V17.5L18.875 18.875M23 17.5C23 20.5375 20.5375 23 17.5 23C14.4625 23 12 20.5375 12 17.5C12 14.4625 14.4625 12 17.5 12C20.5375 12 23 14.4625 23 17.5Z" stroke="#0B3966" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>


            <div class="text-16 font-medium font-second leadin-[20] whitespace-nowrap">Scheduler</div>
        </a>
        <a class="flex flex-col items-center justify-center rounded-xl p-4 gap-2 bg-white hover:bg-bg-footer cursor-pointer">
            <svg width="29" height="20" viewBox="0 0 29 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14.5 6.13567C12.8345 3.2249 10.8143 1 8.48573 1C6.15713 1 1.5 4.3457 1.5 12.1747C1.5 17.9461 2.93413 19 4.46087 19C8.39327 19 12.5724 10.184 14.5 6.13567ZM14.5 6.13567C16.1655 3.2249 18.1857 1 20.5143 1C22.8429 1 27.5 4.3457 27.5 12.1747C27.5 17.9461 26.0659 19 24.5391 19C20.6067 19 16.4276 10.184 14.5 6.13567Z" stroke="#0B3966" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <div class="text-16 font-medium font-second leadin-[20] whitespace-nowrap">Meta Leads</div>
        </a>
    </div>
</div>



<!-- feature -->
<div id="feat-one" class="container flex py-10 gap-6 mdd:flex-col mdd:order-1 mdd:py-5">
    <div class="w-1/2 mdd:order-1 mdd:w-full relative">
        <!-- old version -->

        <!-- <img data-aos="fade-right" src="<?php echo get_template_directory_uri() ?>/assets/images/features/feature1.png" alt="" class="relative feature bg-transparent z-10 w-full"> -->

        <!-- new version 1 -->

        <div class="w-[468px] h-[480px] feature-1 relative">
            <div class="w-[320px] h-[200px] bg-[#CCFFCC] rounded-3xl absolute bottom-0 right-5">
                <img src="<?php echo get_template_directory_uri() ?>/assets/images/features/1/person.png" alt="" class="absolute bottom-0 right-5 z-50">
            </div>
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/features/1/box1.png" alt="" class="absolute bottom-0 left-0">
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/features/1/box2.png" alt="" class="relative top-[23px]">
            <svg width="30" height="53" viewBox="0 0 30 53" fill="none" xmlns="http://www.w3.org/2000/svg" class="absolute top-[115px] right-[222px]">
                <path d="M29 52C22.4375 52 17.0488 52 17.0488 27.4586C17.0488 0.999996 8 0.999999 1 0.999999" stroke="#0B3966" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <div class="absolute right-[7px] top-[60px]">
                <img src=" <?php echo get_template_directory_uri() ?>/assets/images/features/1/box3.png">
                <svg width=" 48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" class="absolute top-0 right-[52px]">
                    <rect width="48" height="48" rx="10" fill="url(#paint0_linear_470_3558)" />
                    <path d="M37 24.0807V30.5404M24 11.8075V17.6211M11 24.0807V30.5404M28 30C25.7908 32.2092 22.2091 32.2092 20 30M30.5 37H17.5C15.7125 37 14.25 35.5466 14.25 33.7702V20.8509C14.25 19.0745 15.7125 17.6211 17.5 17.6211H30.5C32.2875 17.6211 33.75 19.0745 33.75 20.8509V33.7702C33.75 35.5466 32.2875 37 30.5 37ZM20.75 24.8882C20.75 25.3341 20.3862 25.6957 19.9375 25.6957C19.4888 25.6957 19.125 25.3341 19.125 24.8882C19.125 24.4423 19.4888 24.0807 19.9375 24.0807C20.3862 24.0807 20.75 24.4423 20.75 24.8882ZM28.7125 24.8882C28.7125 25.3341 28.3487 25.6957 27.9 25.6957C27.4513 25.6957 27.0875 25.3341 27.0875 24.8882C27.0875 24.4423 27.4513 24.0807 27.9 24.0807C28.3487 24.0807 28.7125 24.4423 28.7125 24.8882ZM25.3 12.2919C25.3 13.0054 24.718 13.5839 24 13.5839C23.282 13.5839 22.7 13.0054 22.7 12.2919C22.7 11.5784 23.282 11 24 11C24.718 11 25.3 11.5784 25.3 12.2919Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" />
                    <defs>
                        <linearGradient id="paint0_linear_470_3558" x1="0.0469" y1="24.0271" x2="48.0473" y2="24.0271" gradientUnits="userSpaceOnUse">
                            <stop offset="0.0192603" stop-color="#25D366" />
                            <stop offset="1" stop-color="#DEDC00" />
                        </linearGradient>
                    </defs>
                </svg>
            </div>
        </div>

        <!-- working version start -->

        <div id="feat-one" class="container flex py-10 gap-6 mdd:flex-col mdd:order-1 mdd:py-5">
            <div class="w-1/2 mdd:order-1 mdd:w-full relative feature-1">
                <!-- <img data-aos="fade-right" src="<?php echo get_template_directory_uri() ?>/assets/images/features/feature1.png" alt="" class="relative feature bg-transparent z-10 w-full"> -->
                <div class=" bg-[#CCFFCC] rounded-3xl absolute right-0 bottom-0 w-[68%] h-[35%]">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/images/features/1/person.png" alt="" class="absolute bottom-0 right-[5%] z-50">
                </div>

                <img src="<?php echo get_template_directory_uri() ?>/assets/images/features/1/box1.png" alt="" class="absolute bottom-0 left-0">
                <!-- <img src="<?php echo get_template_directory_uri() ?>/assets/images/features/1/box2.png" alt="" class="relative top-[23px]">
            <svg width="30" height="53" viewBox="0 0 30 53" fill="none" xmlns="http://www.w3.org/2000/svg" class="absolute top-[115px] right-[222px]">
                <path d="M29 52C22.4375 52 17.0488 52 17.0488 27.4586C17.0488 0.999996 8 0.999999 1 0.999999" stroke="#0B3966" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <div class="absolute right-[7px] top-[60px]">
                <img src=" <?php echo get_template_directory_uri() ?>/assets/images/features/1/box3.png">
                <svg width=" 48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" class="absolute top-0 right-[52px]">
                    <rect width="48" height="48" rx="10" fill="url(#paint0_linear_470_3558)" />
                    <path d="M37 24.0807V30.5404M24 11.8075V17.6211M11 24.0807V30.5404M28 30C25.7908 32.2092 22.2091 32.2092 20 30M30.5 37H17.5C15.7125 37 14.25 35.5466 14.25 33.7702V20.8509C14.25 19.0745 15.7125 17.6211 17.5 17.6211H30.5C32.2875 17.6211 33.75 19.0745 33.75 20.8509V33.7702C33.75 35.5466 32.2875 37 30.5 37ZM20.75 24.8882C20.75 25.3341 20.3862 25.6957 19.9375 25.6957C19.4888 25.6957 19.125 25.3341 19.125 24.8882C19.125 24.4423 19.4888 24.0807 19.9375 24.0807C20.3862 24.0807 20.75 24.4423 20.75 24.8882ZM28.7125 24.8882C28.7125 25.3341 28.3487 25.6957 27.9 25.6957C27.4513 25.6957 27.0875 25.3341 27.0875 24.8882C27.0875 24.4423 27.4513 24.0807 27.9 24.0807C28.3487 24.0807 28.7125 24.4423 28.7125 24.8882ZM25.3 12.2919C25.3 13.0054 24.718 13.5839 24 13.5839C23.282 13.5839 22.7 13.0054 22.7 12.2919C22.7 11.5784 23.282 11 24 11C24.718 11 25.3 11.5784 25.3 12.2919Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" />
                    <defs>
                        <linearGradient id="paint0_linear_470_3558" x1="0.0469" y1="24.0271" x2="48.0473" y2="24.0271" gradientUnits="userSpaceOnUse">
                            <stop offset="0.0192603" stop-color="#25D366" />
                            <stop offset="1" stop-color="#DEDC00" />
                        </linearGradient>
                    </defs>
                </svg>
            </div> -->
            </div>
        </div>

        <!-- working version end -->
        <div class="flex p-5 gap-6 flex-col w-1/2 mdd:w-full mdd:order-2">
            <div class="p-2 rounded-[10px] w-max font-semibold text-14 leading-4 bg-bg-footer text-primary">Chatbot Builder</div>
            <h2 class="font-semibold text-32 leading-[35px] text-primary">Create AI Chatbots Easily with No Code</h2>
            <p class="text-16 leading-[24px]">Design and deploy custom chatbots without technical skills.
                <b>Automate Customer Interactions, Handle FAQs</b> and <b>Provide 24/7 Support</b> with a user-friendly drag-and-drop chatbot builder
            </p>
            <div class="flex gap-6 mdd:flex-col">
                <div class="flex gap-2 flex-col">
                    <h3 class="font-semibold text-primary text-24 leading-[26px]">100%</h3>
                    <div class="w-20 h-1 bg-bg-footer rounded-sm"></div>
                    <p class="text-14 leading-4 font-normal text-primary">Boost in First Response Time</p>
                </div>
                <div class="flex gap-2 flex-col">
                    <h3 class="font-semibold text-primary text-24 leading-[26px]">30%</h3>
                    <div class="w-20 h-1 bg-[#F5EBBA] rounded-sm"></div>
                    <p class="text-14 leading-4 font-normal text-primary">Rise in Sales through Instant Engagement</p>
                </div>
                <div class="flex gap-2 flex-col">
                    <h3 class="font-semibold text-primary text-24 leading-[26px]">25%</h3>
                    <div class="w-20 h-1 bg-[#C4F5C4] rounded-sm"></div>
                    <p class="text-14 leading-4 font-normal text-primary">Improvement in Customer&nbsp;Satisfaction</p>
                </div>
            </div>
            <div class="flex gap-4">
                <a href="#" class="bg-transparent border block w-max border-primary  text-primary text-16 smd:text-14 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                    Learn More
                </a>
                <a href="#" class="bg-primary border block w-max border-primary  text-white text-16 smd:text-14 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                    Start FREE Trial
                </a>
            </div>
        </div>
    </div>
    <div id="feat-two" class="container flex py-10 gap-6 mdd:flex-col mdd:py-5">
        <div class="w-1/2 order-2 mdd:order-1 mdd:w-full">
            <img data-aos="fade-left" src="<?php echo get_template_directory_uri() ?>/assets/images/features/feature1.png" alt="" class="relative feature bg-transparent z-10 w-full">
        </div>
        <div class="flex p-5 gap-6 flex-col w-1/2 order-1 mdd:w-full mdd:order-2">
            <div class="p-2 rounded-[10px] w-max font-semibold text-14 leading-4 bg-bg-footer text-primary">Chatbot Builder</div>
            <h2 class="font-semibold text-32 leading-[35px] text-primary">Create AI Chatbots Easily with No Code</h2>
            <p class="text-16 leading-[24px]">Design and deploy custom chatbots without technical skills.
                <b>Automate Customer Interactions, Handle FAQs</b> and <b>Provide 24/7 Support</b> with a user-friendly drag-and-drop chatbot builder
            </p>
            <div class="flex gap-6 mdd:flex-col">
                <div class="flex gap-2 flex-col">
                    <h3 class="font-semibold text-primary text-24 leading-[26px]">100%</h3>
                    <div class="w-20 h-1 bg-bg-footer rounded-sm"></div>
                    <p class="text-14 leading-4 font-normal text-primary">Boost in First Response Time</p>
                </div>
                <div class="flex gap-2 flex-col">
                    <h3 class="font-semibold text-primary text-24 leading-[26px]">30%</h3>
                    <div class="w-20 h-1 bg-[#F5EBBA] rounded-sm"></div>
                    <p class="text-14 leading-4 font-normal text-primary">Rise in Sales through Instant Engagement</p>
                </div>
                <div class="flex gap-2 flex-col">
                    <h3 class="font-semibold text-primary text-24 leading-[26px]">25%</h3>
                    <div class="w-20 h-1 bg-[#C4F5C4] rounded-sm"></div>
                    <p class="text-14 leading-4 font-normal text-primary">Improvement in Customer&nbsp;Satisfaction</p>
                </div>
            </div>
            <div class="flex gap-4">
                <a href="#" class="bg-transparent border block w-max border-primary  text-primary text-16 smd:text-14 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                    Learn More
                </a>
                <a href="#" class="bg-primary border block w-max border-primary  text-white smd:text-14 text-16 leading-5 font-semibold font-bold py-[10px] px-5 rounded-[20px]">
                    Start FREE Trial
                </a>
            </div>
        </div>
    </div>