<?php

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default. Please note that
 * this is the WordPress construct of pages: specifically, posts with a post
 * type of `page`.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package happilee
 */

get_header();
?>

<section id="primary">
    <main id="main">

        <?php
        get_template_part('template-parts/home/banner');
        get_template_part('template-parts/home/slider');
        get_template_part('template-parts/home/benefits');
        get_template_part('template-parts/home/usecases');
        get_template_part('template-parts/home/features');
        get_template_part('template-parts/home/statistics-uc-effectivenes');
        get_template_part('template-parts/home/integration');
        get_template_part('template-parts/home/testimonials');
        get_template_part('template-parts/home/delight');

        ?>


    </main><!-- #main -->
</section><!-- #primary -->

<?php
get_footer();
